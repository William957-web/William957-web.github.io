from sqlitedict import SqliteDict
db=SqliteDict('example.sqlite')
for key, item in db.items():
    print("%s=%s" % (key, item))

f=open('proof.txt', 'r')
print('Content of proof.txt:')
print(f.read())
